const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Helper function to separate numbers and alphabets
const processData = (data) => {
  const numbers = data.filter((item) => !isNaN(item));
  const alphabets = data.filter((item) => /^[a-zA-Z]$/.test(item));
  const highest_alphabet = alphabets.length ? [alphabets.sort((a, b) => b.localeCompare(a, undefined, { sensitivity: 'base' }))[0]] : [];
  return { numbers, alphabets, highest_alphabet };
};

// POST /bfhl
router.post('/bfhl', async (req, res) => {
  try {
    const { data } = req.body;
    if (!Array.isArray(data)) return res.status(400).json({ is_success: false, message: "Invalid data format" });

    const { numbers, alphabets, highest_alphabet } = processData(data);
    const response = {
      is_success: true,
      user_id: "john_doe_17091999",
      email: "john@xyz.com",
      roll_number: "ABCD123",
      numbers,
      alphabets,
      highest_alphabet,
    };

    // Save to MongoDB
    await User.create(response);
    res.json(response);
  } catch (err) {
    res.status(500).json({ is_success: false, message: err.message });
  }
});

// GET /bfhl
router.get('/bfhl', (req, res) => res.status(200).json({ operation_code: 1 }));

module.exports = router;
